import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-local';
import { UsersService } from './users.service';
export class CurrentUser {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
}
@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy, 'local') {
  constructor(private userService: UsersService) {
    super({ usernameField: 'username' });
  }

  async validate(username: string, password: string): Promise<CurrentUser> {
    const user = await this.userService.validateUserCredentials(
      username,
      password,
    );
    Logger.log('user', user);

    if (user == null) {
      throw new UnauthorizedException();
    }
    return user;
  }
}
