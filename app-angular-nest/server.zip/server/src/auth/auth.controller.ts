import {
  Body,
  Request,
  Controller,
  Post,
  HttpCode,
  HttpStatus,
  Get,
  Logger,
  UseGuards,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { GuardService } from './guard/guard.service';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @HttpCode(HttpStatus.OK)
  @Post('login')
  signIn(@Body() signInDto: Record<string, any>) {
    Logger.log('info', signInDto);
    return this.authService.signIn(signInDto.username, signInDto.password);
  }

  @UseGuards(GuardService)
  @Get('profile')
  getProfile(@Request() req) {
    return req.user;
  }
}
