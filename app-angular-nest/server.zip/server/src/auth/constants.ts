export const jwtConstants = {
  secret: 'nest_app',
};
